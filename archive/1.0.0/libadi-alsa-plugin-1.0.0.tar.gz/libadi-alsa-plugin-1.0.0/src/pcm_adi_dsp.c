/*
 * ALSA <-> OSS PCM I/O plugin
 *
 * Copyright (c) 2005 by Takashi Iwai <tiwai@suse.de>
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

#include <stdio.h>
#include <sys/ioctl.h>
#include <alsa/asoundlib.h>
#include <alsa/pcm_external.h>
#include <linux/soundcard.h>

/* ADSP parameters */

struct adsp_parms {
	int core_id;
	int mode;
};

SND_PCM_PLUGIN_DEFINE_FUNC(adi_dsp)
{
	snd_config_iterator_t i, next;
	snd_config_t *slave = NULL;
	int err;
	struct adsp_parms parms = {
		.core_id = 1,
		.mode = 1,
	};

	printf("SULLIAN ADSP \n");

	snd_config_for_each(i, next, conf) {
		snd_config_t *n = snd_config_iterator_entry(i);
		const char *id;
		if (snd_config_get_id(n, &id) < 0)
			continue;
		if (strcmp(id, "comment") == 0 || strcmp(id, "type") == 0 ||
			strcmp(id, "hint") == 0)
			continue;
		if (strcmp(id, "slave") == 0) {
			slave = n;
			continue;
		}
		err = get_int_parm(n, id, "core_id", &parms.core_id);
		if (err)
			goto ok;
		err = get_int_parm(n, id, "mode", &parms.core_id);
		if (err)
			goto ok;
		SNDERR("Unknown field %s", id);
		return -EINVAL;
	ok:
		if (err < 0)
			return err;
	}

	if(!slave) {
		NDERR("No slave configuration for adsp pcm");
		return -EINVAL;
	}

	return 0;

 error:

	return err;
}

SND_PCM_PLUGIN_SYMBOL(adi_dsp);
